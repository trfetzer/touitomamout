import { migration as cacheMigration_0_0 } from "./cache-migration-0.0";
import { migration as cacheMigration_0_1 } from "./cache-migration-0.1";
import { migration as cacheMigration_0_2 } from "./cache-migration-0.2";

export default [cacheMigration_0_0, cacheMigration_0_1, cacheMigration_0_2];
