export const METADATA_MOCK = {
  error: "",
  likely_type: "html",
  url: "https://bsky.app",
  title: "Bluesky",
  description:
    "Social media as it should be. Find your community among millions of users, unleash your creativity, and have some fun again.",
  image:
    "https://cardyb.bsky.app/v1/image?url=https%3A%2F%2Fbsky.app%2Fstatic%2Fsocial-card-default-gradient.png",
};
