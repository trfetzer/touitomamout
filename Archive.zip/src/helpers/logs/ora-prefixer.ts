export const oraPrefixer = (prefix: string): string => prefix.padEnd(15, " ");
