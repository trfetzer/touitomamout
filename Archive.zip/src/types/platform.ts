export enum Platform {
  MASTODON = "mastodon",
  BLUESKY = "bluesky",
}
