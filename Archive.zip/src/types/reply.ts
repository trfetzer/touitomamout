export type ReplyEntry = {
  root: {
    cid: string;
    uri: string;
  };
  parent: {
    cid: string;
    uri: string;
  };
};
