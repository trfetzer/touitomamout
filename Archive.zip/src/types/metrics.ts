export type Metrics = {
  totalSynced: number;
  justSynced: number;
};
