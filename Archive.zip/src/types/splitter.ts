export type SplitterEntry = { str: string; sep: string };
