:::tip Environment file generator

Feel free to generate your `.env` file with the [generator](/docs/tools/env-generator)
:::
