Assuming you have a folder /home/[user]/services

**Clone** the project
```bash
cd /home/[user]/services && git clone https://github.com/louisgrasset/touitomamout.git
```

**Install** dependencies & build the project
```bash
npm ci && npm run build 
```
